const db = require('../config/db');

//GET
exports.filter = async (req, res)=>{ }

///POST
exports.create = async (req, res) => { }

///PUT
exports.update = async (req, res) => { }

///DEL
exports.delete = async (req, res) => { }

//PUT
exports.changeStatus = async (req, res) => { }
